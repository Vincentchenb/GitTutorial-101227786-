#ifndef TAARRAY_H
#define TAARRAY_H

#include "TextArea.h"
#include "defs.h"

class TAArray {
    private:
        TextArea** elements;   // Dynamically allocated array of TextArea pointers
        int size;              // Current number of elements in the array
    
    public:
        TAArray();
        ~TAArray();
        
        bool add(TextArea* ta);                   // Add to back of array
        bool add(TextArea* ta, int index);        // Add at specific index
        
        // Get functions
        TextArea* get(string id);
        TextArea* get(int index);
        
        // Const get functions
        TextArea* get(string id) const;
        TextArea* get(int index) const;
        
        // Remove functions
        TextArea* remove(string id);
        TextArea* remove(int index);
        
        // Size accessor
        int getSize() const;
        
        // Print function
        void print() const;

#endif